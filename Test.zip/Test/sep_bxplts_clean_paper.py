
import cv2
import os
import shutil
import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
import matplotlib


import seaborn as sns
sns.set_style("whitegrid")
sns.set(font_scale = 2)

# FOLDER PATH TO WRITE THE INFERENCES
SAVE_FOLDER_NAME = "SEPERATE_BOXPLOTS_CLEAN"
if not os.path.isdir(SAVE_FOLDER_NAME):
    os.mkdir(SAVE_FOLDER_NAME)
    
    

df_A = pd.read_csv("A.txt", sep=" ", header=None, names=["index", "Dice", "IoU", "Hausdorff_100", "Hausdorff_95"])
df_B = pd.read_csv("B.txt", sep=" ", header=None, names=["index", "Dice", "IoU", "Hausdorff_100", "Hausdorff_95"])

df_C = pd.read_csv("C.txt", sep=" ", header=None, names=["index", "Dice", "IoU", "Hausdorff_100", "Hausdorff_95"])
df_D  = pd.read_csv("D.txt", sep=" ", header=None, names=["index", "Dice", "IoU", "Hausdorff_100", "Hausdorff_95"])

df_E  = pd.read_csv("E.txt", sep=" ", header=None, names=["index", "Dice", "IoU", "Hausdorff_100", "Hausdorff_95"]) 
df_F  = pd.read_csv("F.txt", sep=" ", header=None, names=["index", "Dice", "IoU", "Hausdorff_100", "Hausdorff_95"])  

df_G = pd.read_csv("G.txt", sep=" ", header=None, names=["index", "Dice", "IoU", "Hausdorff_100", "Hausdorff_95"])  
df_H = pd.read_csv("H.txt", sep=" ", header=None, names=["index", "Dice", "IoU", "Hausdorff_100", "Hausdorff_95"])  

# print(df_A)


# Create a list of columns to plot
columns = ["Dice", "IoU", "Hausdorff_100", "Hausdorff_95"]
COLUMNS_PLT = ["Dice Coef.", "IoU", "Hausdorff 100", "Hausdorff 95"]


# the destination folder name which you want to save the images
COLUMN_SAVE = 'Hausdorff_95'
# Define the column here which you want to seperate the images for
SOURCE_FOLDER = 'test_dump_UNet_BCE/'
#SOURCE_FOLDER = 'N_Grid_Stretch_white_padding_16grids/'



try:
    os.makedirs(COLUMN_SAVE)
except:
    print("Making folder for ",COLUMN_SAVE)
    


# https://stackoverflow.com/questions/63792528/boxplot-custom-width-in-seaborn
# Create the box plots

FULL_METRICS = {}

# Initialize an empty DataFrame with column names
df_FULL_Dice = pd.DataFrame(columns=['index', 'Model_Name', 'Legend', 'value'])

index = 0
print("Columns = ",columns)

for column, col_plt in zip(columns, COLUMNS_PLT):
    print("Column = ",column)
    if column == 'Dice':
        
        for item in df_A[column]:
            df_FULL_Dice = pd.concat([df_FULL_Dice, pd.DataFrame({'index': [index], 'Model_Name': ['A'], 'Legend': ['SOTA'], 'value': [item]})], ignore_index=True)
            index += 1
        for item in df_B[column]:
            df_FULL_Dice = pd.concat([df_FULL_Dice, pd.DataFrame({'index': [index], 'Model_Name': ['B'], 'Legend': ['Proposed'], 'value': [item]})], ignore_index=True)
            index += 1
        
        for item in df_C[column]:
            df_FULL_Dice = pd.concat([df_FULL_Dice, pd.DataFrame({'index': [index], 'Model_Name': ['C'], 'Legend': ['SOTA'], 'value': [item]})], ignore_index=True)
            index += 1
        for item in df_D[column]:
            df_FULL_Dice = pd.concat([df_FULL_Dice, pd.DataFrame({'index': [index], 'Model_Name': ['D'], 'Legend': ['Proposed'], 'value': [item]})], ignore_index=True)
            index += 1
        
        for item in df_E[column]:
            df_FULL_Dice = pd.concat([df_FULL_Dice, pd.DataFrame({'index': [index], 'Model_Name': ['E'], 'Legend': ['SOTA'], 'value': [item]})], ignore_index=True)
            index += 1
        for item in df_F[column]:
            df_FULL_Dice = pd.concat([df_FULL_Dice, pd.DataFrame({'index': [index], 'Model_Name': ['F'], 'Legend': ['Proposed'], 'value': [item]})], ignore_index=True)    
            index += 1
            
        for item in df_G[column]:
            df_FULL_Dice = pd.concat([df_FULL_Dice, pd.DataFrame({'index': [index], 'Model_Name': ['G'], 'Legend': ['SOTA'], 'value': [item]})], ignore_index=True)
            index += 1
        for item in df_H[column]:
            df_FULL_Dice = pd.concat([df_FULL_Dice, pd.DataFrame({'index': [index], 'Model_Name': ['H'], 'Legend': ['Proposed'], 'value': [item]})], ignore_index=True)
            index += 1


print(df_FULL_Dice)

b = sns.boxplot(x="Model_Name", y="value", hue="Legend", palette="magma", data=df_FULL_Dice, width=0.85, showfliers=False, showmeans=True)

b.set_xlabel('Models used', fontsize=20)
# b.set_ylabel(r'$\textbf{Value}$',fontsize=15)
b.set_ylabel('Dice Coef.',fontsize=20)
b.tick_params(labelsize=20)
b.tick_params(axis='x', rotation=70)
b.tick_params(axis='y')
plt.ylim((.96, 1.0))
plt.yticks(np.arange(0.96, 1.0, 0.01).tolist())
plt.rc('xtick', labelsize=20)
plt.rc('ytick', labelsize=20)
plt.legend(loc=1,frameon="True", fancybox="True", shadow=True, framealpha=0.25, prop={'size': 15})

# plt.tight_layout()
plt.savefig(SAVE_FOLDER_NAME+"/"+"Dice_plt_paper.png", bbox_inches='tight', dpi=500)
plt.savefig(SAVE_FOLDER_NAME+"/"+"Dice_plt_paper.eps", bbox_inches='tight', dpi=500)
plt.show()
